# Rentenrechner Web-App

## Anleitung zum Starten

1. Node.js installieren (https://nodejs.org/)
2. Terminal öffnen und in dieses Verzeichnis wechseln
3. `npm install` ausführen, um Abhängigkeiten zu installieren
4. `npm start` ausführen, um die App lokal zu starten
5. Für Deployment auf Vercel: Repository hochladen und Vercel verbinden

---

## Beschreibung

Diese einfache React-Web-App ermöglicht das Eingeben von Einkommen, Zielrente und erwarteten Renten aus AHV, PK und 3a. Sie zeigt ein Säulendiagramm mit der Rentenlücke und bietet PDF-Export.