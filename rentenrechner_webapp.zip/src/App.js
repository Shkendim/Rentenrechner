import React, { useState } from "react";
import { Bar } from "react-chartjs-2";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

function App() {
  const [einkommen, setEinkommen] = useState(100000);
  const [zielRente, setZielRente] = useState(70000);
  const [ahv, setAhv] = useState(20000);
  const [pk, setPk] = useState(30000);
  const [dreiA, setDreiA] = useState(10000);

  const rentenluecke = zielRente - (ahv + pk + dreiA);

  const chartData = {
    labels: ["AHV", "Pensionskasse", "Säule 3a", "Zielrente", "Lücke"],
    datasets: [
      {
        label: "Beträge in CHF",
        data: [ahv, pk, dreiA, zielRente, rentenluecke > 0 ? rentenluecke : 0],
        backgroundColor: [
          "#4caf50",
          "#2196f3",
          "#ff9800",
          "#9e9e9e",
          "#f44336",
        ],
      },
    ],
  };

  const exportAsPDF = () => {
    const input = document.getElementById("chart-section");
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();
      pdf.addImage(imgData, "PNG", 10, 10, 190, 100);
      pdf.save("Rentenrechner.pdf");
    });
  };

  return (
    <div style={{ maxWidth: 600, margin: "2rem auto", fontFamily: "Arial, sans-serif" }}>
      <h1>Rentenrechner</h1>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
        <div>
          <label>Jahreseinkommen (CHF)</label>
          <input
            type="number"
            value={einkommen}
            onChange={(e) => setEinkommen(Number(e.target.value))}
            style={{ width: "100%", padding: "0.5rem", marginTop: "0.25rem" }}
          />
        </div>
        <div>
          <label>Zielrente pro Jahr (CHF)</label>
          <input
            type="number"
            value={zielRente}
            onChange={(e) => setZielRente(Number(e.target.value))}
            style={{ width: "100%", padding: "0.5rem", marginTop: "0.25rem" }}
          />
        </div>
        <div>
          <label>Erwartete AHV (CHF)</label>
          <input
            type="number"
            value={ahv}
            onChange={(e) => setAhv(Number(e.target.value))}
            style={{ width: "100%", padding: "0.5rem", marginTop: "0.25rem" }}
          />
        </div>
        <div>
          <label>Erwartete Pensionskasse (CHF)</label>
          <input
            type="number"
            value={pk}
            onChange={(e) => setPk(Number(e.target.value))}
            style={{ width: "100%", padding: "0.5rem", marginTop: "0.25rem" }}
          />
        </div>
        <div>
          <label>Erwartete Säule 3a (CHF)</label>
          <input
            type="number"
            value={dreiA}
            onChange={(e) => setDreiA(Number(e.target.value))}
            style={{ width: "100%", padding: "0.5rem", marginTop: "0.25rem" }}
          />
        </div>
      </div>
      <div id="chart-section" style={{ marginTop: "2rem", backgroundColor: "#fff", padding: "1rem", borderRadius: 8, boxShadow: "0 2px 5px rgba(0,0,0,0.1)" }}>
        <Bar
          data={chartData}
          options={{ responsive: true, maintainAspectRatio: false }}
          height={300}
        />
      </div>
      <div style={{ textAlign: "right", marginTop: "1rem" }}>
        <button onClick={exportAsPDF} style={{ padding: "0.5rem 1rem", cursor: "pointer" }}>
          Exportieren als PDF
        </button>
      </div>
    </div>
  );
}

export default App;